#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

typedef struct tree
{
	int key;
	struct tree* left;
	struct tree* right;
} tree;


tree* create(int key)
{
	tree* node = (tree*)malloc(sizeof(tree));
	node->key = key;
	node->left = NULL;
	node->right = NULL;
	return node;
}

tree* build_tree(char* t, int *pos)
{
	
	int key = 0, len = strlen(t);
	tree* node = NULL;
	bool neg = false;
	
	if(t[*pos] == '-')
	{
		neg = true;
		(*pos)++;
	}
	
	if(isdigit(t[*pos]))
	{
		while(*pos<len && isdigit(t[*pos]))
			key = key*10 + (t[(*pos)++] - 48);
		
		if(neg)
			key*=-1;
		
		node = create(key);
		
	}
	
	if(*pos< len && t[*pos] == '(')
	{
		*pos = *pos+1;
		node->left = build_tree(t, pos);
	}
	
	if(*pos < len && t[*pos] == ')')
		{ (*pos)++; return node; }
	
	if(*pos< len && t[*pos] == '(')
	{
		*pos = *pos+1;
		node->right = build_tree(t, pos);
	}
	
	if(*pos < len && t[*pos] == ')')
		{ (*pos)++; return node; }
	
	return node;
}

float find_s(tree* root , int k , int *count)
{
	if(root!=NULL)
	{
		float res = find_s(root->left, k, count);
		if(res!=0.5)
			return res;
		(*count)++;
		if(*count == k)
			return root->key;
		res = find_s(root->right, k, count);
		if(res!=0.5)
			return res;
	}
	return 0.5;
}

int search_kth_smallest(tree* root , int k)
{
	int count = 0;
	return (int)find_s(root, k, &count);
	
}

float find_l(tree* root , int k , int *count)
{
	if(root!=NULL)
	{
		float res = find_l(root->right, k, count);
		if(res!=0.5)
			return res;
		(*count)++;
		if(*count == k)
			return root->key;
		res = find_l(root->left, k, count);
		if(res!=0.5)
			return res;
	}
	return 0.5;
}

tree* tree_min(tree* node)
{
	if(node->left == NULL)
		return node;
	else
		return tree_min(node->left);
}

tree* tree_max(tree* node)
{
	if(node->right == NULL)
		return node;
	else
		return tree_max(node->right);
}

tree* search(tree* root, int key)
{
	if (root == NULL || root->key == key)
		return root;
	else
	{
		if(key < root->key)
			search(root->left, key);
		else
			search(root->right, key);
	}
}

int search_kth_largest(tree* root , int k)
{
	int count = 0;
	return (int)find_l(root, k, &count);
	
}

void inorder(tree* root)
{
	if(root!=NULL)
	{
		inorder(root->left);
		printf("%d ",root->key);
		inorder(root->right);
	}
	
}

void main()
{
	int key,sum = 0, i = -1;
	char opt;
	tree *root=NULL, *node;
	char *t = (char*)malloc(2048*sizeof(char)),c;
	
	while(scanf("%c",&c) && c  != '\n')
	{
		if(c == ' ')
			continue;
		if(i<0)
		{
			i++;
			continue;
		}
		else
			t[i++] = c;
	}
	
	t[--i] = '\0';
	
	if(i!=0)
	{
	
		t = (char*)realloc(t, sizeof(char)* i);
		i =0;
		scanf("%d",&key);
		root = build_tree(t,&i);
		scanf("%c",&opt);	
		while(opt!='e')
		{
			switch(opt)
				{
					case 'i': inorder(root);
						printf("\n");
						break;
		
			
					case 'r': 
						scanf("%d",&key);
						node = search(root,key);
						if(node == NULL)
							printf("-1\n");
						else if(node->left == NULL)
							printf("%d\n",(node->left)->key);
						else
						{
							node =tree_max(node->left);
							printf("%d\n",node->key);
						}
						break;
					case 'u': 
						scanf("%d",&key);
						node = search(root,key);
						if(node == NULL)
							printf("-1\n");
						else if(node->right == NULL)
							printf("%d\n",(node->right)->key);
						else
						{
							node =tree_min(node->right);
							printf("%d\n",node->key);
						}
						break;
					case 'l': 
						scanf("%d",&key);
						printf("%d\n",search_kth_largest(root,key));
						break;
					case 's':
						scanf("%d",&key);
						printf("%d\n",search_kth_smallest(root,key));
						break;
												
				}
			scanf("%c",&opt);
		}
	}
	
}

