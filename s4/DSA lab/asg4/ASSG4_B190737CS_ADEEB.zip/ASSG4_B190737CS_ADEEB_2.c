#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ctype.h>

#define nil ((void*)-1)

typedef struct set
{
    int key;
    int rank;
    struct set* parent;

}set;

typedef struct linkedList
{
    int key, weight;  
    struct linkedList* next;    
}ll;

typedef struct edge
{
    int u, v, w;
}edge;

set* makeset(int key)
{
    set* node = (set*)malloc(sizeof(set));
    node->parent = node;
    node->key = key;
    node->rank = 0;

    return node;
}


void insert(set** forest, set* node)
{
    float h = (node->key)%256, i = -1;
    int pos;

    while(++i < 256)
    {
        pos = (int)(h + 0.5*i + 0.5*i*i)%256;
        if(forest[pos] == NULL || forest[pos] == nil)
        {
            forest[pos] = node;
            return;
        }    

        if(forest[pos]->key == node->key)
        {
            free(node);
            return;
        }    
    }

}

void link(set* x, set* y)
{
    if(x->rank >= y->rank)
    {
        printf("%d ",x->key);
        y->parent = x;
    }
    else
    {
        printf("%d ",y->key);
        x->parent = y;
    }

    if(x->rank == y->rank)
        (x->rank)++;
}

set* findSet(set* x, int* count)
{
    (*count)++;
    if(x == x->parent)
        return x;

    x->parent = findSet(x->parent,count);
    return x->parent;
}

void Union(set*x, set* y, int* count)
{
    if(x == NULL || y == NULL)
    {
        printf("-1\n");
        return;
    }

    link(findSet(x,count),findSet(y,count));
    printf("\n");

}

set* search(set** forest, int x)
{
    float h = x%256, i = -1;
    int pos;

    while(++i < 256)
    {
        pos = (int)(h + 0.5*i + 0.5*i*i)%256;
        
        if(forest[pos] == NULL || forest[pos]->key == x)
            return forest[pos];

    }

    return NULL;

}


void main()
{
    char opt;
    set** forest = (set**)calloc(512, sizeof(set*));
    int v, e = 0, t =0;
    edge *edg = (edge*)malloc(100*sizeof(edge));
 
    scanf("%c%d",&opt,&v);

    for(int i = 0; i < v; i++)
    {
        char k;
        int j = 0;
        while(scanf("%c",&k) && k != '\n')
        {
            if(isdigit(k))
                j = j * 10 + (int)(k - 48);

            if(k == ' ')
            {
                if(i != j)
                {
                    edg[e++].u = i;
                    edg[e].v = j;
                }
                j = 0;
            }
        }   


        insert(forest, makeset(i));

    }

    edge *ed = (edge*)malloc(e * sizeof(edge));
    e = 0;

    for(int i = 0; i < v; i++)
    {
        char k;
        int j=0, s = 0;
        while(scanf("%c",&k) && k != '\n')
        {
            if(isdigit(k))
            {
                if( s == 0)
                    continue;
                j = j * 10 + (int)(k - 48);
            }

            if(k == ' ')
            {
                s++;
                if( edg[t].u > edg[t++].v)
                {
                    ed[e].u = edg[t-1].u;
                    ed[e].v = edg[t-1].v;
                    ed[e++].w = j;
                }
                
                j = 0;
            }
        }

    }

    free(edg);
    ed = (edge*)realloc(ed, e * sizeof(edge));
    
    printf("0\n0\n");
    



}
/*
a
7
0 1 5
1 0 2 6
2 1 3
3 2 4 6
4 3 5 6
5 0 4
6 1 3 4
0 28 10
1 28 16 14
2 16 12
3 12 22 18
4 22 25 24
5 10 25
6 14 18 24

*/